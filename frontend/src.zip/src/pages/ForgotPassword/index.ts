export { ForgotPasswordPage } from './ForgotPasswordPage'
