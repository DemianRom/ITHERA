export { RegisterPage } from './RegisterPage'
