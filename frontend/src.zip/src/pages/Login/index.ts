export { LoginPage } from './LoginPage'
