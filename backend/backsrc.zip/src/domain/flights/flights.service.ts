import { createOfferRequest, DuffelOffer, DuffelSegment, DuffelSlice } from '../../infrastructure/external-apis/duffel.service';
import { FlightBaggage, FlightOffer, FlightSegment, FlightSliceSummary, SearchFlightsParams } from './flights.entity';

const DEFAULT_MAX_RESULTS = 20;
const MAX_TRIP_PEOPLE = 50;

function parseIsoDate(value: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const date = new Date(`${value}T00:00:00Z`);
  return Number.isNaN(date.getTime()) ? null : date;
}

function diffDays(start: string, end: string): number | null {
  const startDate = parseIsoDate(start);
  const endDate = parseIsoDate(end);
  if (!startDate || !endDate) return null;
  return Math.round((endDate.getTime() - startDate.getTime()) / 86400000);
}
const FALLBACK_USD_TO_MXN = 17.2;

function currencyRateToMxn(currency: string | null | undefined): number {
  const normalized = (currency ?? '').toUpperCase();
  if (normalized === 'MXN') return 1;
  if (normalized === 'USD') return Number(process.env['USD_MXN_RATE'] ?? FALLBACK_USD_TO_MXN);
  return 1;
}

function convertPriceToMxn(amount: number | null, currency: string | null | undefined): number | null {
  if (amount === null) return null;
  return Math.round(amount * currencyRateToMxn(currency) * 100) / 100;
}

function toNumber(value: string | null | undefined): number | null {
  if (value === undefined || value === null || value === '') return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function normalizeIata(value: string | null | undefined): string | null {
  return value ? value.toUpperCase() : null;
}

function buildFlightNumber(segment: DuffelSegment | undefined): string | null {
  if (!segment) return null;

  const carrierCode =
    segment.marketing_carrier?.iata_code ??
    segment.operating_carrier?.iata_code ??
    null;

  const flightNumber =
    segment.marketing_carrier_flight_number ??
    segment.operating_carrier_flight_number ??
    null;

  if (!carrierCode || !flightNumber) return null;
  return `${carrierCode}${flightNumber}`;
}

function collectBaggage(segment: DuffelSegment | undefined): FlightBaggage[] {
  const raw = segment?.passengers?.[0]?.baggages ?? [];
  return raw
    .filter((item) => item.type && typeof item.quantity === 'number')
    .map((item) => ({
      type: String(item.type),
      quantity: Number(item.quantity),
    }));
}

function normalizeSegment(segment: DuffelSegment): FlightSegment {
  const operatingCarrier = segment.operating_carrier ?? segment.marketing_carrier ?? null;

  return {
    origin: normalizeIata(segment.origin?.iata_code),
    originName: segment.origin?.name ?? segment.origin?.city_name ?? null,
    destination: normalizeIata(segment.destination?.iata_code),
    destinationName: segment.destination?.name ?? segment.destination?.city_name ?? null,
    departureAt: segment.departing_at ?? null,
    arrivalAt: segment.arriving_at ?? null,
    duration: segment.duration ?? null,
    airline: operatingCarrier?.name ?? null,
    airlineCode: normalizeIata(operatingCarrier?.iata_code),
    flightNumber: buildFlightNumber(segment),
    aircraft: segment.aircraft?.name ?? null,
    stops: Array.isArray(segment.stops) ? segment.stops.length : 0,
  };
}

function summarizeSlice(slice: DuffelSlice | undefined): FlightSliceSummary | null {
  if (!slice) return null;

  const segments = (slice.segments ?? []).map(normalizeSegment);
  const firstSegment = segments[0];
  const lastSegment = segments[segments.length - 1] ?? firstSegment;
  const connectionStops = Math.max(segments.length - 1, 0);
  const technicalStops = segments.reduce((sum, segment) => sum + segment.stops, 0);

  return {
    origin: firstSegment?.origin ?? normalizeIata(slice.origin?.iata_code),
    originName: firstSegment?.originName ?? slice.origin?.name ?? slice.origin?.city_name ?? null,
    destination: lastSegment?.destination ?? normalizeIata(slice.destination?.iata_code),
    destinationName: lastSegment?.destinationName ?? slice.destination?.name ?? slice.destination?.city_name ?? null,
    departureAt: firstSegment?.departureAt ?? null,
    arrivalAt: lastSegment?.arrivalAt ?? null,
    duration: slice.duration ?? firstSegment?.duration ?? null,
    stops: connectionStops + technicalStops,
    segments,
  };
}

function normalizeOffer(offer: DuffelOffer, params: SearchFlightsParams): FlightOffer {
  const slices = offer.slices ?? [];
  const outboundSlice = summarizeSlice(slices[0]);
  const returnSlice = summarizeSlice(slices[1]);
  const firstSegment = slices[0]?.segments?.[0];
  const owner = offer.owner ?? firstSegment?.operating_carrier ?? firstSegment?.marketing_carrier ?? null;

  const adults = Math.max(1, params.adults ?? 1);
  const children = Math.max(0, params.children ?? 0);
  const infantsWithoutSeat = Math.max(0, params.infantsWithoutSeat ?? 0);

  const originalPrice = toNumber(offer.total_amount);
  const originalCurrency = offer.total_currency ?? null;

  return {
    id: offer.id ?? '',
    provider: 'duffel',
    liveMode: Boolean(offer.live_mode),
    airline: owner?.name ?? null,
    airlineCode: normalizeIata(owner?.iata_code),
    flightNumber: buildFlightNumber(firstSegment),
    origin: outboundSlice?.origin ?? null,
    originName: outboundSlice?.originName ?? null,
    destination: outboundSlice?.destination ?? null,
    destinationName: outboundSlice?.destinationName ?? null,
    departureAt: outboundSlice?.departureAt ?? null,
    arrivalAt: outboundSlice?.arrivalAt ?? null,
    duration: outboundSlice?.duration ?? null,
    stops: outboundSlice?.stops ?? 0,
    price: convertPriceToMxn(originalPrice, originalCurrency),
    currency: 'MXN',
    cabinClass: firstSegment?.passengers?.[0]?.cabin_class ?? params.cabinClass ?? 'economy',
    fareBrand: slices[0]?.fare_brand_name ?? null,
    aircraft: firstSegment?.aircraft?.name ?? null,
    baggage: collectBaggage(firstSegment),
    passengers: {
      adults,
      children,
      infantsWithoutSeat,
      total: adults + children + infantsWithoutSeat,
    },
    outboundSlice,
    returnSlice,
    slices: slices.map((slice) => (slice.segments ?? []).map(normalizeSegment)),
    raw: { ...(offer as unknown as Record<string, unknown>), originalPrice, originalCurrency },
  };
}

function validateParams(params: SearchFlightsParams): void {
  if (!params.origin || !params.destination || !params.departureDate) {
    throw Object.assign(new Error('origin, destination y departureDate son requeridos'), { statusCode: 400 });
  }

  if (!/^[A-Z]{3}$/.test(params.origin) || !/^[A-Z]{3}$/.test(params.destination)) {
    throw Object.assign(new Error('Origen y destino deben ser códigos IATA válidos de 3 letras'), { statusCode: 400 });
  }

  if (params.origin === params.destination) {
    throw Object.assign(new Error('El origen y el destino no pueden ser iguales'), { statusCode: 400 });
  }

  if (!parseIsoDate(params.departureDate)) {
    throw Object.assign(new Error('La fecha de salida debe tener formato YYYY-MM-DD'), { statusCode: 400 });
  }

  if (params.returnDate) {
    const days = diffDays(params.departureDate, params.returnDate);
    if (days === null) {
      throw Object.assign(new Error('La fecha de regreso debe tener formato YYYY-MM-DD'), { statusCode: 400 });
    }

    if (days < 1) {
      throw Object.assign(new Error('La fecha de regreso debe ser posterior a la salida'), { statusCode: 400 });
    }

  }

  const adults = params.adults ?? 1;
  const children = params.children ?? 0;
  const infantsWithoutSeat = params.infantsWithoutSeat ?? 0;

  if (adults < 1 || children < 0 || infantsWithoutSeat < 0) {
    throw Object.assign(new Error('Los pasajeros deben ser cantidades positivas válidas'), { statusCode: 400 });
  }

  if (infantsWithoutSeat > adults) {
    throw Object.assign(new Error('No puede haber más infantes sin asiento que adultos'), { statusCode: 400 });
  }

  if (adults + children + infantsWithoutSeat > MAX_TRIP_PEOPLE) {
    throw Object.assign(new Error(`La búsqueda permite máximo ${MAX_TRIP_PEOPLE} pasajeros en total`), { statusCode: 400 });
  }
}

export async function searchFlights(params: SearchFlightsParams): Promise<FlightOffer[]> {
  const normalizedParams: SearchFlightsParams = {
    ...params,
    origin: params.origin.toUpperCase().trim(),
    destination: params.destination.toUpperCase().trim(),
    adults: Math.max(1, params.adults ?? 1),
    children: Math.max(0, params.children ?? 0),
    infantsWithoutSeat: Math.max(0, params.infantsWithoutSeat ?? 0),
    cabinClass: params.cabinClass ?? 'economy',
    max: Math.max(1, Math.min(params.max ?? DEFAULT_MAX_RESULTS, 50)),
  };

  validateParams(normalizedParams);

  const response = await createOfferRequest(normalizedParams);
  const offers = response.data?.offers ?? [];

  return offers
    .map((offer) => normalizeOffer(offer, normalizedParams))
    .filter((offer) => offer.id)
    .slice(0, normalizedParams.max);
}
