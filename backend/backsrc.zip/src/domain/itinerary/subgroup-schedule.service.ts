import { supabase } from "../../infrastructure/db/supabase.client";
import { getLocalUserId } from "../groups/groups.service";
import * as NotificationsService from "../notifications/notifications.service";

type Role = "admin" | "viajero";

const emitSubgroupScheduleUpdated = (
  groupId: string,
  tipo: string,
  entidadTipo: string,
  entidadId: string | number | null,
  actorUsuarioId: string | number | null,
  metadata: Record<string, unknown> = {},
): void => {
  NotificationsService.emitGroupDashboardUpdated(Number(groupId), {
    tipo,
    entidadTipo,
    entidadId: entidadId !== null ? Number(entidadId) : null,
    actorUsuarioId: actorUsuarioId !== null ? Number(actorUsuarioId) : null,
    metadata: { itemType: "subgrupo", ...metadata },
  });
};

const isThirtyMinuteBoundary = (value: string): boolean => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return false;
  return (
    date.getUTCSeconds() === 0 &&
    date.getUTCMilliseconds() === 0 &&
    date.getUTCMinutes() % 30 === 0
  );
};

const getMexicoDateOnly = (date: Date): string => {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Mexico_City",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const byType = Object.fromEntries(
    parts.map((part) => [part.type, part.value]),
  );
  return `${byType.year}-${byType.month}-${byType.day}`;
};

const getTodayDateOnly = (): string => getMexicoDateOnly(new Date());

const assertDateIsNotInPast = (
  value?: string | null,
  message = "No puedes crear o modificar elementos en dias anteriores al actual.",
): void => {
  if (!value) return;
  const parsed = new Date(value);
  const day = Number.isNaN(parsed.getTime())
    ? String(value).slice(0, 10)
    : getMexicoDateOnly(parsed);
  if (day && day < getTodayDateOnly()) {
    throw Object.assign(new Error(message), { statusCode: 400 });
  }
};

const toScheduleRange = (startsAt?: string | null, endsAt?: string | null) => {
  if (!startsAt) return null;

  const startMs = new Date(startsAt).getTime();
  if (!Number.isFinite(startMs)) return null;

  const endCandidateMs = endsAt ? new Date(endsAt).getTime() : NaN;
  const endMs =
    Number.isFinite(endCandidateMs) && endCandidateMs > startMs
      ? endCandidateMs
      : startMs;

  return {
    day: String(startsAt).slice(0, 10),
    startMs,
    endMs,
  };
};

const getScheduleMinuteKey = (value?: string | null): string | null => {
  if (!value) return null;
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return null;

  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Mexico_City",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  const byType = Object.fromEntries(
    parts.map((part) => [part.type, part.value]),
  );
  return `${byType.year}-${byType.month}-${byType.day}T${byType.hour}:${byType.minute}`;
};

const scheduleRangesOverlap = (
  left: NonNullable<ReturnType<typeof toScheduleRange>>,
  right: NonNullable<ReturnType<typeof toScheduleRange>>,
): boolean => {
  if (left.day !== right.day) return false;

  const leftEndExclusive =
    left.endMs > left.startMs ? left.endMs : left.startMs + 1;
  const rightEndExclusive =
    right.endMs > right.startMs ? right.endMs : right.startMs + 1;

  return left.startMs < rightEndExclusive && right.startMs < leftEndExclusive;
};

const validateSlotDateRules = async (
  groupId: string,
  startsAt: string,
  endsAt: string,
) => {
  assertDateIsNotInPast(
    startsAt,
    "No puedes crear o modificar horarios de subgrupos en dias anteriores al actual.",
  );

  const starts = new Date(startsAt);
  const ends = new Date(endsAt);
  if (Number.isNaN(starts.getTime()) || Number.isNaN(ends.getTime())) {
    throw Object.assign(
      new Error("Fechas inválidas para horario de subgrupos"),
      { statusCode: 400 },
    );
  }
  if (ends.getTime() <= starts.getTime()) {
    throw Object.assign(
      new Error("La fecha fin debe ser mayor a la fecha inicio"),
      { statusCode: 400 },
    );
  }
  if (!isThirtyMinuteBoundary(startsAt) || !isThirtyMinuteBoundary(endsAt)) {
    throw Object.assign(
      new Error("Los horarios deben estar en intervalos de 30 minutos exactos"),
      { statusCode: 400 },
    );
  }

  const { data: group, error } = await supabase
    .from("grupos_viaje")
    .select("fecha_inicio, fecha_fin")
    .eq("id", groupId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!group)
    throw Object.assign(new Error("Grupo no encontrado"), { statusCode: 404 });
  if (!group.fecha_inicio || !group.fecha_fin) {
    throw Object.assign(
      new Error(
        "El viaje debe tener fecha de inicio y fin para usar subgrupos",
      ),
      { statusCode: 400 },
    );
  }

  const startDay = getMexicoDateOnly(starts);
  const endDay = getMexicoDateOnly(ends);
  if (
    startDay < String(group.fecha_inicio) ||
    endDay > String(group.fecha_fin)
  ) {
    throw Object.assign(
      new Error(
        `El horario debe estar dentro del rango del viaje (${group.fecha_inicio} a ${group.fecha_fin})`,
      ),
      { statusCode: 400 },
    );
  }
};

const ensureSlotHasNoScheduleCollision = async (
  groupId: string,
  startsAt: string,
  endsAt: string,
  excludeSlotId?: string | null,
) => {
  const candidateRange = toScheduleRange(startsAt, endsAt);
  if (!candidateRange) return;

  const { data: slots, error: slotsError } = await supabase
    .from("subgroup_slots")
    .select("id, title, starts_at, ends_at")
    .eq("group_id", groupId);
  if (slotsError) throw new Error(slotsError.message);

  const conflictingSlot = (slots ?? []).find((slot: any) => {
    if (excludeSlotId && String(slot.id) === String(excludeSlotId))
      return false;
    const slotRange = toScheduleRange(
      slot.starts_at ? String(slot.starts_at) : null,
      slot.ends_at ? String(slot.ends_at) : null,
    );
    return slotRange ? scheduleRangesOverlap(candidateRange, slotRange) : false;
  });

  if (conflictingSlot) {
    throw Object.assign(
      new Error(
        `Este horario de subgrupos se empalma con "${String((conflictingSlot as any).title ?? "otro horario de subgrupos")}"`,
      ),
      { statusCode: 409 },
    );
  }

  const { data: itinerary, error: itineraryError } = await supabase
    .from("itinerarios")
    .select("id_itinerario")
    .eq("grupo_id", groupId)
    .maybeSingle();
  if (itineraryError) throw new Error(itineraryError.message);
  if (!itinerary) return;

  const { data: activities, error: activitiesError } = await supabase
    .from("actividades")
    .select("id_actividad, titulo, fecha_inicio, fecha_fin, estado")
    .eq("itinerario_id", (itinerary as any).id_itinerario);
  if (activitiesError) throw new Error(activitiesError.message);

  const conflictingActivity = (activities ?? []).find((activity: any) => {
    if (String(activity.estado ?? "") === "cancelada") return false;
    const activityRange = toScheduleRange(
      activity.fecha_inicio ? String(activity.fecha_inicio) : null,
      activity.fecha_fin ? String(activity.fecha_fin) : null,
    );
    return activityRange
      ? scheduleRangesOverlap(candidateRange, activityRange)
      : false;
  });

  if (conflictingActivity) {
    throw Object.assign(
      new Error(
        `Este horario de subgrupos se empalma con la actividad "${String((conflictingActivity as any).titulo ?? "Actividad existente")}"`,
      ),
      { statusCode: 409 },
    );
  }
};

const ensureGroupMember = async (authUserId: string, groupId: string) => {
  const userId = await getLocalUserId(authUserId);
  const { data, error } = await supabase
    .from("grupo_miembros")
    .select("id, rol")
    .eq("grupo_id", groupId)
    .eq("usuario_id", userId)
    .maybeSingle();

  if (error) throw new Error(error.message);
  if (!data)
    throw Object.assign(new Error("No perteneces a este grupo"), {
      statusCode: 403,
    });

  return {
    userId: Number(userId),
    role: String((data as any).rol ?? "viajero") as Role,
  };
};

const ensureGroupAdmin = async (authUserId: string, groupId: string) => {
  const member = await ensureGroupMember(authUserId, groupId);
  if (member.role !== "admin") {
    throw Object.assign(
      new Error("Solo admin puede administrar horarios de subgrupos"),
      { statusCode: 403 },
    );
  }
  return member;
};

const ensureSlotInGroup = async (slotId: string, groupId: string) => {
  const { data, error } = await supabase
    .from("subgroup_slots")
    .select("*")
    .eq("id", slotId)
    .eq("group_id", groupId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data)
    throw Object.assign(new Error("Horario de subgrupos no encontrado"), {
      statusCode: 404,
    });
  return data;
};

const ensureSubgroupInSlot = async (subgroupId: string, slotId: string) => {
  const { data, error } = await supabase
    .from("subgroups")
    .select("*")
    .eq("id", subgroupId)
    .eq("slot_id", slotId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data)
    throw Object.assign(new Error("Subgrupo no encontrado en este horario"), {
      statusCode: 404,
    });
  return data;
};

export const getSubgroupSchedule = async (
  authUserId: string,
  groupId: string,
) => {
  const member = await ensureGroupMember(authUserId, groupId);

  const { data: slots, error: slotsError } = await supabase
    .from("subgroup_slots")
    .select("*")
    .eq("group_id", groupId)
    .order("starts_at", { ascending: true });
  if (slotsError) throw new Error(slotsError.message);

  const slotIds = (slots ?? []).map((slot: any) => slot.id);
  if (slotIds.length === 0) {
    return { slots: [], myUserId: member.userId };
  }

  const [
    { data: subgroups, error: subgroupsError },
    { data: activities, error: activitiesError },
    { data: memberships, error: membershipsError },
  ] = await Promise.all([
    supabase
      .from("subgroups")
      .select("*")
      .in("slot_id", slotIds)
      .order("created_at", { ascending: true }),
    supabase
      .from("subgroup_activities")
      .select("*")
      .in("slot_id", slotIds)
      .order("created_at", { ascending: true }),
    supabase
      .from("subgroup_memberships")
      .select("*, usuarios!user_id(id_usuario, nombre, email, avatar_url)")
      .in("slot_id", slotIds),
  ]);

  if (subgroupsError) throw new Error(subgroupsError.message);
  if (activitiesError) throw new Error(activitiesError.message);
  if (membershipsError) throw new Error(membershipsError.message);

  const subgroupsBySlot = new Map<number, any[]>();
  for (const subgroup of subgroups ?? []) {
    const slotId = Number((subgroup as any).slot_id);
    const list = subgroupsBySlot.get(slotId) ?? [];
    list.push(subgroup);
    subgroupsBySlot.set(slotId, list);
  }

  const activitiesBySubgroup = new Map<number, any[]>();
  for (const activity of activities ?? []) {
    const subgroupId = Number((activity as any).subgroup_id);
    const list = activitiesBySubgroup.get(subgroupId) ?? [];
    list.push(activity);
    activitiesBySubgroup.set(subgroupId, list);
  }

  const membershipsBySlot = new Map<number, any[]>();
  for (const row of memberships ?? []) {
    const slotId = Number((row as any).slot_id);
    const list = membershipsBySlot.get(slotId) ?? [];
    const user = (row as any).usuarios ?? null;
    list.push({
      ...row,
      usuarios: user,
      user,
    });
    membershipsBySlot.set(slotId, list);
  }

  const normalizedSlots = (slots ?? []).map((slot: any) => {
    const slotSubgroups = (subgroupsBySlot.get(Number(slot.id)) ?? [])
      .map((subgroup: any) => ({
        ...subgroup,
        activities: [
          ...(activitiesBySubgroup.get(Number(subgroup.id)) ?? []),
        ].sort((left: any, right: any) => {
          const leftTime = left?.starts_at
            ? new Date(String(left.starts_at)).getTime()
            : Number.MAX_SAFE_INTEGER;
          const rightTime = right?.starts_at
            ? new Date(String(right.starts_at)).getTime()
            : Number.MAX_SAFE_INTEGER;
          if (leftTime !== rightTime) return leftTime - rightTime;
          return Number(left?.id ?? 0) - Number(right?.id ?? 0);
        }),
        members: (membershipsBySlot.get(Number(slot.id)) ?? []).filter(
          (m: any) =>
            m.subgroup_id != null &&
            Number(m.subgroup_id) === Number(subgroup.id),
        ),
      }))
      .sort((left: any, right: any) => {
        const leftPrimary = left.activities[0]?.starts_at
          ? new Date(String(left.activities[0].starts_at)).getTime()
          : Number.MAX_SAFE_INTEGER;
        const rightPrimary = right.activities[0]?.starts_at
          ? new Date(String(right.activities[0].starts_at)).getTime()
          : Number.MAX_SAFE_INTEGER;
        if (leftPrimary !== rightPrimary) return leftPrimary - rightPrimary;
        return Number(left?.id ?? 0) - Number(right?.id ?? 0);
      });

    return {
      ...slot,
      subgroups: slotSubgroups,
      memberships: membershipsBySlot.get(Number(slot.id)) ?? [],
    };
  });

  return { slots: normalizedSlots, myUserId: member.userId };
};

export const createSlot = async (
  authUserId: string,
  groupId: string,
  payload: {
    title: string;
    description?: string | null;
    starts_at: string;
    ends_at: string;
  },
) => {
  const admin = await ensureGroupAdmin(authUserId, groupId);
  await validateSlotDateRules(groupId, payload.starts_at, payload.ends_at);
  await ensureSlotHasNoScheduleCollision(
    groupId,
    payload.starts_at,
    payload.ends_at,
  );

  const { data, error } = await supabase
    .from("subgroup_slots")
    .insert({
      group_id: Number(groupId),
      title: payload.title,
      description: payload.description ?? null,
      starts_at: payload.starts_at,
      ends_at: payload.ends_at,
      created_by: admin.userId,
    })
    .select("*")
    .single();
  if (error || !data)
    throw new Error(error?.message ?? "No se pudo crear horario");
  emitSubgroupScheduleUpdated(
    groupId,
    "subgrupo_horario_creado",
    "subgroup_slot",
    (data as { id?: string | number | null }).id ?? null,
    admin.userId,
    {
      itemTitle: payload.title,
      startsAt: payload.starts_at,
      endsAt: payload.ends_at,
    },
  );
  return data;
};

export const updateSlot = async (
  authUserId: string,
  groupId: string,
  slotId: string,
  payload: Partial<{
    title: string;
    description: string | null;
    starts_at: string;
    ends_at: string;
  }>,
) => {
  await ensureGroupAdmin(authUserId, groupId);
  const current = await ensureSlotInGroup(slotId, groupId);
  const nextStartsAt = payload.starts_at ?? String((current as any).starts_at);
  const nextEndsAt = payload.ends_at ?? String((current as any).ends_at);
  await validateSlotDateRules(groupId, nextStartsAt, nextEndsAt);
  await ensureSlotHasNoScheduleCollision(
    groupId,
    nextStartsAt,
    nextEndsAt,
    slotId,
  );

  const { data, error } = await supabase
    .from("subgroup_slots")
    .update({
      ...(payload.title !== undefined ? { title: payload.title } : {}),
      ...(payload.description !== undefined
        ? { description: payload.description }
        : {}),
      ...(payload.starts_at !== undefined
        ? { starts_at: payload.starts_at }
        : {}),
      ...(payload.ends_at !== undefined ? { ends_at: payload.ends_at } : {}),
      updated_at: new Date().toISOString(),
    })
    .eq("id", slotId)
    .eq("group_id", groupId)
    .select("*")
    .single();
  if (error || !data)
    throw new Error(error?.message ?? "No se pudo actualizar horario");
  const actor = await ensureGroupMember(authUserId, groupId);
  emitSubgroupScheduleUpdated(
    groupId,
    "subgrupo_horario_actualizado",
    "subgroup_slot",
    slotId,
    actor.userId,
    {
      itemTitle: (data as any).title,
      startsAt: (data as any).starts_at,
      endsAt: (data as any).ends_at,
    },
  );
  return data;
};

export const deleteSlot = async (
  authUserId: string,
  groupId: string,
  slotId: string,
) => {
  await ensureGroupAdmin(authUserId, groupId);
  await ensureSlotInGroup(slotId, groupId);
  const { error } = await supabase
    .from("subgroup_slots")
    .delete()
    .eq("id", slotId)
    .eq("group_id", groupId);
  if (error) throw new Error(error.message);
  const actor = await ensureGroupMember(authUserId, groupId);
  emitSubgroupScheduleUpdated(
    groupId,
    "subgrupo_horario_eliminado",
    "subgroup_slot",
    slotId,
    actor.userId,
  );
};

export const createSubgroup = async (
  authUserId: string,
  groupId: string,
  slotId: string,
  payload: { name: string; description?: string | null },
) => {
  const member = await ensureGroupMember(authUserId, groupId);
  await ensureSlotInGroup(slotId, groupId);

  const { data, error } = await supabase
    .from("subgroups")
    .insert({
      slot_id: Number(slotId),
      name: payload.name,
      description: payload.description ?? null,
      created_by: member.userId,
    })
    .select("*")
    .single();
  if (error || !data)
    throw new Error(error?.message ?? "No se pudo crear subgrupo");

  const { error: membershipError } = await supabase
    .from("subgroup_memberships")
    .upsert(
      {
        slot_id: Number(slotId),
        subgroup_id: Number(
          (data as { id?: string | number | null }).id ?? null,
        ),
        user_id: member.userId,
        assigned_by: member.userId,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "slot_id,user_id" },
    );
  if (membershipError) {
    await supabase
      .from("subgroups")
      .delete()
      .eq("id", (data as { id?: string | number | null }).id ?? null);
    throw new Error(membershipError.message);
  }

  emitSubgroupScheduleUpdated(
    groupId,
    "subgrupo_creado",
    "subgroup",
    (data as { id?: string | number | null }).id ?? null,
    member.userId,
    {
      itemTitle: payload.name,
      slotId: Number(slotId),
    },
  );

  return data;
};

export const updateSubgroup = async (
  authUserId: string,
  groupId: string,
  slotId: string,
  subgroupId: string,
  payload: Partial<{ name: string; description: string | null }>,
) => {
  const member = await ensureGroupMember(authUserId, groupId);
  const subgroup = await ensureSubgroupInSlot(subgroupId, slotId);
  const isOwner = Number((subgroup as any).created_by) === member.userId;
  const isAdmin = member.role === "admin";
  if (!isOwner && !isAdmin) {
    throw Object.assign(
      new Error("Solo creador o admin puede editar subgrupos"),
      { statusCode: 403 },
    );
  }

  const { data, error } = await supabase
    .from("subgroups")
    .update({
      ...(payload.name !== undefined ? { name: payload.name } : {}),
      ...(payload.description !== undefined
        ? { description: payload.description }
        : {}),
      updated_at: new Date().toISOString(),
    })
    .eq("id", subgroupId)
    .eq("slot_id", slotId)
    .select("*")
    .single();
  if (error || !data)
    throw new Error(error?.message ?? "No se pudo actualizar subgrupo");
  emitSubgroupScheduleUpdated(
    groupId,
    "subgrupo_actualizado",
    "subgroup",
    subgroupId,
    member.userId,
    {
      itemTitle: (data as any).name,
      slotId: Number(slotId),
    },
  );
  return data;
};

export const deleteSubgroup = async (
  authUserId: string,
  groupId: string,
  slotId: string,
  subgroupId: string,
) => {
  const member = await ensureGroupMember(authUserId, groupId);
  const subgroup = await ensureSubgroupInSlot(subgroupId, slotId);
  const isOwner = Number((subgroup as any).created_by) === member.userId;
  const isAdmin = member.role === "admin";
  if (!isOwner && !isAdmin) {
    throw Object.assign(
      new Error("Solo creador o admin puede eliminar subgrupos"),
      { statusCode: 403 },
    );
  }

  const { error } = await supabase
    .from("subgroups")
    .delete()
    .eq("id", subgroupId)
    .eq("slot_id", slotId);
  if (error) throw new Error(error.message);
  emitSubgroupScheduleUpdated(
    groupId,
    "subgrupo_eliminado",
    "subgroup",
    subgroupId,
    member.userId,
    {
      slotId: Number(slotId),
    },
  );
};

export const joinSubgroup = async (
  authUserId: string,
  groupId: string,
  slotId: string,
  subgroupId: string | null,
) => {
  const member = await ensureGroupMember(authUserId, groupId);
  await ensureSlotInGroup(slotId, groupId);
  if (subgroupId) await ensureSubgroupInSlot(subgroupId, slotId);

  const { data: currentMembership, error: currentMembershipError } =
    await supabase
      .from("subgroup_memberships")
      .select("subgroup_id")
      .eq("slot_id", slotId)
      .eq("user_id", member.userId)
      .maybeSingle();
  if (currentMembershipError) throw new Error(currentMembershipError.message);

  const currentSubgroupId = (currentMembership as any)?.subgroup_id;
  if (currentSubgroupId && Number(currentSubgroupId) !== Number(subgroupId)) {
    const { count, error: countError } = await supabase
      .from("subgroup_memberships")
      .select("id", { count: "exact", head: true })
      .eq("slot_id", slotId)
      .eq("subgroup_id", currentSubgroupId)
      .neq("user_id", member.userId);
    if (countError) throw new Error(countError.message);
    if ((count ?? 0) === 0) {
      throw Object.assign(
        new Error(
          "El subgrupo debe tener al menos una persona. Eliminalo o espera a que alguien mas se una.",
        ),
        { statusCode: 400 },
      );
    }
  }

  const now = new Date().toISOString();
  const { data, error } = await supabase
    .from("subgroup_memberships")
    .upsert(
      {
        slot_id: Number(slotId),
        subgroup_id: subgroupId ? Number(subgroupId) : null,
        user_id: member.userId,
        assigned_by: member.userId,
        updated_at: now,
      },
      { onConflict: "slot_id,user_id" },
    )
    .select("*")
    .single();
  if (error || !data)
    throw new Error(error?.message ?? "No se pudo actualizar tu subgrupo");

  emitSubgroupScheduleUpdated(
    groupId,
    "subgrupo_miembro_actualizado",
    "subgroup_membership",
    (data as { id?: string | number | null }).id ?? null,
    member.userId,
    {
      slotId: Number(slotId),
      subgroupId: subgroupId ? Number(subgroupId) : null,
      previousSubgroupId: currentSubgroupId ? Number(currentSubgroupId) : null,
    },
  );

  return data;
};

const ensureSubgroupActivityHasNoTimeCollision = async (
  slotId: string,
  startsAt?: string | null,
  excludeActivityId?: string | null,
) => {
  const candidateMinuteKey = getScheduleMinuteKey(startsAt);
  if (!candidateMinuteKey) return;

  const { data: activities, error } = await supabase
    .from("subgroup_activities")
    .select("id, title, starts_at")
    .eq("slot_id", slotId);
  if (error) throw new Error(error.message);

  const conflictingActivity = (activities ?? []).find((activity: any) => {
    if (excludeActivityId && String(activity.id) === String(excludeActivityId))
      return false;
    return (
      getScheduleMinuteKey(
        activity.starts_at ? String(activity.starts_at) : null,
      ) === candidateMinuteKey
    );
  });

  if (conflictingActivity) {
    throw Object.assign(
      new Error(
        `Ya existe una actividad en este horario: "${String((conflictingActivity as any).title ?? "Actividad existente")}"`,
      ),
      { statusCode: 409 },
    );
  }
};

export const createSubgroupActivity = async (
  authUserId: string,
  groupId: string,
  slotId: string,
  subgroupId: string,
  payload: {
    title: string;
    description?: string | null;
    location?: string | null;
    starts_at?: string | null;
    ends_at?: string | null;
  },
) => {
  const member = await ensureGroupMember(authUserId, groupId);
  const slot = await ensureSlotInGroup(slotId, groupId);
  await ensureSubgroupInSlot(subgroupId, slotId);

  assertDateIsNotInPast(
    String((slot as any).starts_at),
    "Este horario corresponde a un dia anterior. Solo puede consultarse.",
  );

  const startsAt = payload.starts_at ?? null;
  if (startsAt) {
    assertDateIsNotInPast(
      startsAt,
      "No puedes crear actividades de subgrupo en dias anteriores al actual.",
    );
    assertDateIsNotInPast(
      startsAt,
      "No puedes crear o modificar horarios de subgrupos en dias anteriores al actual.",
    );

    const starts = new Date(startsAt);
    const slotStarts = new Date(String((slot as any).starts_at));
    const slotEnds = new Date(String((slot as any).ends_at));
    if (
      Number.isNaN(starts.getTime()) ||
      starts < slotStarts ||
      starts >= slotEnds
    ) {
      throw Object.assign(
        new Error(
          "La hora estimada debe estar dentro del horario de subgrupos y antes de la hora de termino",
        ),
        { statusCode: 400 },
      );
    }
    if (!isThirtyMinuteBoundary(startsAt)) {
      throw Object.assign(
        new Error(
          "La hora estimada debe estar en intervalos de 30 minutos exactos",
        ),
        { statusCode: 400 },
      );
    }
    await ensureSubgroupActivityHasNoTimeCollision(slotId, startsAt);
  }

  const { data, error } = await supabase
    .from("subgroup_activities")
    .insert({
      slot_id: Number(slotId),
      subgroup_id: Number(subgroupId),
      title: payload.title,
      description: payload.description ?? null,
      location: payload.location ?? null,
      starts_at: payload.starts_at ?? null,
      ends_at:
        payload.ends_at ?? (startsAt ? String((slot as any).ends_at) : null),
      created_by: member.userId,
    })
    .select("*")
    .single();
  if (error || !data)
    throw new Error(error?.message ?? "No se pudo crear actividad");
  emitSubgroupScheduleUpdated(
    groupId,
    "subgrupo_actividad_creada",
    "subgroup_activity",
    (data as { id?: string | number | null }).id ?? null,
    member.userId,
    {
      itemTitle: payload.title,
      slotId: Number(slotId),
      subgroupId: Number(subgroupId),
      startsAt: payload.starts_at ?? null,
    },
  );
  return data;
};

export const updateSubgroupActivity = async (
  authUserId: string,
  groupId: string,
  slotId: string,
  activityId: string,
  payload: Partial<{
    title: string;
    description: string | null;
    location: string | null;
    starts_at: string | null;
    ends_at: string | null;
  }>,
) => {
  const member = await ensureGroupMember(authUserId, groupId);
  const slot = await ensureSlotInGroup(slotId, groupId);

  const { data: activity, error: activityError } = await supabase
    .from("subgroup_activities")
    .select("*")
    .eq("id", activityId)
    .eq("slot_id", slotId)
    .maybeSingle();
  if (activityError) throw new Error(activityError.message);
  if (!activity)
    throw Object.assign(new Error("Actividad de subgrupo no encontrada"), {
      statusCode: 404,
    });

  assertDateIsNotInPast(
    String((slot as any).starts_at),
    "Este horario corresponde a un dia anterior. Solo puede consultarse.",
  );

  const isOwner = Number((activity as any).created_by) === member.userId;
  const isAdmin = member.role === "admin";
  if (!isOwner && !isAdmin) {
    throw Object.assign(
      new Error("Solo creador o admin puede editar actividades"),
      { statusCode: 403 },
    );
  }

  if (payload.starts_at !== undefined) {
    const nextStartsAt = payload.starts_at ?? null;
    if (nextStartsAt) {
      const starts = new Date(nextStartsAt);
      const slotStarts = new Date(String((slot as any).starts_at));
      const slotEnds = new Date(String((slot as any).ends_at));
      if (
        Number.isNaN(starts.getTime()) ||
        starts < slotStarts ||
        starts >= slotEnds
      ) {
        throw Object.assign(
          new Error(
            "La hora estimada debe estar dentro del horario de subgrupos y antes de la hora de termino",
          ),
          { statusCode: 400 },
        );
      }
      if (!isThirtyMinuteBoundary(nextStartsAt)) {
        throw Object.assign(
          new Error(
            "La hora estimada debe estar en intervalos de 30 minutos exactos",
          ),
          { statusCode: 400 },
        );
      }
      await ensureSubgroupActivityHasNoTimeCollision(
        slotId,
        nextStartsAt,
        activityId,
      );
    }
  }

  const { data, error } = await supabase
    .from("subgroup_activities")
    .update({
      ...(payload.title !== undefined ? { title: payload.title } : {}),
      ...(payload.description !== undefined
        ? { description: payload.description }
        : {}),
      ...(payload.location !== undefined ? { location: payload.location } : {}),
      ...(payload.starts_at !== undefined
        ? { starts_at: payload.starts_at }
        : {}),
      ...(payload.ends_at !== undefined ? { ends_at: payload.ends_at } : {}),
      updated_at: new Date().toISOString(),
    })
    .eq("id", activityId)
    .eq("slot_id", slotId)
    .select("*")
    .single();
  if (error || !data)
    throw new Error(error?.message ?? "No se pudo actualizar actividad");
  emitSubgroupScheduleUpdated(
    groupId,
    "subgrupo_actividad_actualizada",
    "subgroup_activity",
    activityId,
    member.userId,
    {
      itemTitle: (data as any).title,
      slotId: Number(slotId),
      startsAt: (data as any).starts_at ?? null,
    },
  );
  return data;
};

export const deleteSubgroupActivity = async (
  authUserId: string,
  groupId: string,
  slotId: string,
  activityId: string,
) => {
  const member = await ensureGroupMember(authUserId, groupId);
  const slot = await ensureSlotInGroup(slotId, groupId);

  const { data: activity, error: activityError } = await supabase
    .from("subgroup_activities")
    .select("*")
    .eq("id", activityId)
    .eq("slot_id", slotId)
    .maybeSingle();
  if (activityError) throw new Error(activityError.message);
  if (!activity)
    throw Object.assign(new Error("Actividad de subgrupo no encontrada"), {
      statusCode: 404,
    });

  assertDateIsNotInPast(
    String((slot as any).starts_at),
    "Este horario corresponde a un dia anterior. Solo puede consultarse.",
  );

  const isOwner = Number((activity as any).created_by) === member.userId;
  const isAdmin = member.role === "admin";
  if (!isOwner && !isAdmin) {
    throw Object.assign(
      new Error("Solo creador o admin puede eliminar actividades"),
      { statusCode: 403 },
    );
  }

  const { error } = await supabase
    .from("subgroup_activities")
    .delete()
    .eq("id", activityId)
    .eq("slot_id", slotId);
  if (error) throw new Error(error.message);
  emitSubgroupScheduleUpdated(
    groupId,
    "subgrupo_actividad_eliminada",
    "subgroup_activity",
    activityId,
    member.userId,
    {
      slotId: Number(slotId),
    },
  );
};
